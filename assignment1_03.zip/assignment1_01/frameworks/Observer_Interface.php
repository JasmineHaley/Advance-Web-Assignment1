<?php
	interface Observer_Interface {
		public function update (Observable_Model $o);
	}

?>