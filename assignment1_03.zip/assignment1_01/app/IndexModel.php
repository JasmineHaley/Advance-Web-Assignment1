<?php
class IndexModel extends Observable_Model {
	public function getAll():array{
		$courses=json_decode($this->loadData('courses'),true);
		$instructor=json_decode($this->loadData('instructor'),true);
		$course_instructor=json_decode($this->loadData('course_instructor'),true);

		$popular_column = array_column($courses["courses"],3);
		$recommended_column = array_column($courses["courses"],2);
		$c = $courses["courses"];

		array_multisort($recommended_column,SORT_DESC,$c);
		
		$recommended = array_slice($courses["courses"],0,8);

		array_multisort($popular_column,SORT_DESC,$c);
		$popular = array_slice($courses["courses"],0,8);
		
		//var_dump($courses["courses"]);
		$instructors=[];
		foreach($courses["courses"] as $key=>$value){
			foreach($course_instructor["course_instructor"] as $k=>$val){
				if($key == $k){
					$instructors[$value[0]]=$instructor["instructors"][$val];
				}
			}
		}
		
		return ['popular'=>$popular,'recommended'=>$recommended,'instructors'=>$instructors];
		

	}
	public function getRecord(String $id):array{
		return [];
	}
}
?>