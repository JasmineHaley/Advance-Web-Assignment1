<?php 


//directories 
const ROOT_DIR2='/Applications/XAMPP/xamppfiles/htdocs/Web2/assignment1_00';
const TEMPLATE_DIR= ROOT_DIR2.'/templates';


 ?>