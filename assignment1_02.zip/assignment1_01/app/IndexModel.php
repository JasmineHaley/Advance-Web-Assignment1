<?php
class IndexModel extends Observable_Model {
	public function getAll():array{
		$courses=json_decode($this->loadData('courses'),true);
		$instructors=json_decode($this->loadData('instructor'),true);
		$course_instructor=json_decode($this->loadData('course_instructor'),true);

		$popular_column = array_column($courses["courses"],3);
		$recommended_column = array_column($courses["courses"],2);
		//var_dump($popular_column);

		array_multisort($recommended_column,SORT_DESC,$courses["courses"]);
		//var_dump(array_slice($courses["courses"],0));
		$recommended = array_slice($courses["courses"],0,8);

		array_multisort($popular_column,SORT_DESC,$courses["courses"]);
		$popular = array_slice($courses["courses"],0,8);
		
		//var_dump($popular);
		
		return ['popular'=>$popular,'recommended'=>$recommended];
		

	}
	public function getRecord(String $id):array{
		return [];
	}
}
?>