<?php 

require 'autoloader.php';
 require 'config.php'; 

$controller = new CoursesController();
$controller->run();
 ?>