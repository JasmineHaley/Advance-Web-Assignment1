<?php
class ProfileModel extends Observable_Model{
	public function getAll():array{
		return [];
	}
	public function getRecord(String $id):array{
		return [];
	}
}?>