<?php 

require 'autoloader.php';
 require 'config.php'; 

$controller = new SignUpController();
$controller->run();
 ?>